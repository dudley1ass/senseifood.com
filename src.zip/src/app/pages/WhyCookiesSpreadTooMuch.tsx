import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCookiesSpreadTooMuch() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cookie Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cookies Spread Too Much
          </h1>
          <p className="text-xl text-muted-foreground">
            Diagnosing the root causes of overly flat cookies and how to fix them every time.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              You pull your cookies from the oven and they've spread into thin, lacy puddles. Over-spreading is one of the most frustrating baking problems, but it has clear causes and straightforward fixes. The key is identifying which variable is responsible.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Over-spreading happens when the fats in the dough melt and spread faster than the proteins and starches can set and hold shape. Multiple factors can contribute at once.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Butter Too Soft or Melted</h3>
                <p className="text-muted-foreground leading-relaxed">This is the #1 cause. Melted or very soft butter spreads instantly in the oven before anything can set. Always use butter that holds its shape but yields to pressure — about 65°F.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Dough Not Chilled</h3>
                <p className="text-muted-foreground leading-relaxed">Warm dough goes into a hot oven and spreads immediately. Chilling firms the fat back up, slowing the spread and giving structure time to set first.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Too Much Butter or Fat</h3>
                <p className="text-muted-foreground leading-relaxed">High butter ratios relative to flour means more spreading force. If your recipe yields very flat cookies consistently, try reducing butter by 10–15%.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Wrong Sugar Ratio</h3>
                <p className="text-muted-foreground leading-relaxed">White sugar spreads more than brown. If your recipe calls for mostly white sugar and you're getting too much spread, swapping some for brown sugar (which is drier and more hygroscopic) can help.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Too Little Flour</h3>
                <p className="text-muted-foreground leading-relaxed">Low flour content means insufficient structure. If you're at altitude, humidity, or used a different flour brand, you may need a tablespoon or two more flour.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Old or Weak Leavening</h3>
                <p className="text-muted-foreground leading-relaxed">Expired baking soda or powder means cookies spread sideways instead of rising up. Test baking soda by dropping in vinegar — it should bubble vigorously.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Quick Fixes for Too Much Spread</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Chill dough 1–2 hours (or overnight) before baking</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use cold butter cut into pieces instead of softened</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Add 2 tbsp extra flour to the dough</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Swap 25% of white sugar for brown sugar</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Check leavening freshness — replace if over 6 months old</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Chill dough before baking</li>
                  <li>• Use fresh leavening</li>
                  <li>• Add more flour if needed</li>
                  <li>• Use brown sugar</li>
                  <li>• Bake one test cookie first</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Bake warm dough</li>
                  <li>• Use melted butter</li>
                  <li>• Skip the test cookie</li>
                  <li>• Use expired baking soda</li>
                  <li>• Crowd the baking sheet</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cookie-science/why-cookies-flatten" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Flatten</h4>
                <p className="text-sm text-muted-foreground">The full science of flat cookies</p>
              </Link>
              <Link to="/cookie-science/why-cookies-dont-spread" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Don't Spread</h4>
                <p className="text-sm text-muted-foreground">When cookies stay too puffy</p>
              </Link>
              <Link to="/cookie-science/why-cookies-spread" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Spread</h4>
                <p className="text-sm text-muted-foreground">Understanding cookie spread</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
