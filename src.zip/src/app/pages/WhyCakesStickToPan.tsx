import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCakesStickToPan() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cake Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cakes Stick to the Pan
          </h1>
          <p className="text-xl text-muted-foreground">
            The science of cake release and how to ensure a clean, perfect unmold every time.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Few things are more frustrating than a beautifully baked cake that tears apart when you try to remove it from the pan. Sticking is caused by sugar caramelization bonding to the pan, insufficient fat barrier, or removing the cake too soon (or too late).
            </p>
            <p className="text-muted-foreground leading-relaxed">
              The good news: sticking is almost entirely preventable with proper pan preparation. Understanding why it happens makes it easy to prevent every time.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Inadequate Pan Greasing</h3>
                <p className="text-muted-foreground leading-relaxed">A thin or uneven layer of fat leaves gaps where batter can bond directly to the pan. Grease every surface — sides included — with butter or shortening (not cooking spray alone for delicate cakes).</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Skipping the Flour Dusting</h3>
                <p className="text-muted-foreground leading-relaxed">For layer cakes, butter alone isn't always enough. A light dusting of flour (or cocoa powder for chocolate cakes) over the greased pan creates a physical barrier the cake can release from.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Not Using Parchment</h3>
                <p className="text-muted-foreground leading-relaxed">Lining the bottom of round pans with parchment paper is the most reliable way to ensure clean release. Cut a circle to fit, grease the pan, lay parchment, then grease again.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Removing Too Soon</h3>
                <p className="text-muted-foreground leading-relaxed">Removing a cake from the pan while it's still very hot means the structure is fragile and the sugars are still liquid and sticky. Cool in the pan 10–15 minutes first.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Waiting Too Long</h3>
                <p className="text-muted-foreground leading-relaxed">On the flip side, leaving the cake in the pan too long after cooling allows condensation to form and steam to soften the crust, creating a sticky bond. Unmold while still slightly warm.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. High Sugar Recipes</h3>
                <p className="text-muted-foreground leading-relaxed">Cakes with very high sugar content (like sticky toffee or caramel cakes) are especially prone to sticking because caramelized sugar acts as a glue. These always need parchment.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Perfect Pan Prep Every Time</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Grease pan thoroughly with butter or shortening — not just spray</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Line bottom with parchment paper cut to fit</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Grease again over the parchment</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Dust with flour (or cocoa) and tap out excess</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Cool 10–15 min in pan, then unmold onto wire rack</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use parchment paper</li>
                  <li>• Grease all surfaces</li>
                  <li>• Cool 10–15 min before unmolding</li>
                  <li>• Run a knife around edges</li>
                  <li>• Use butter not spray for delicate cakes</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Skip the parchment</li>
                  <li>• Use cooking spray alone</li>
                  <li>• Unmold immediately</li>
                  <li>• Leave in pan overnight</li>
                  <li>• Pull cake straight up without loosening</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cake-science/why-cakes-collapse" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Collapse</h4>
                <p className="text-sm text-muted-foreground">Structural failure in cakes</p>
              </Link>
              <Link to="/cake-science/why-cakes-dry-out" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Dry Out</h4>
                <p className="text-sm text-muted-foreground">Moisture retention in cakes</p>
              </Link>
              <Link to="/cake-science/why-cakes-are-dense" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Are Dense</h4>
                <p className="text-sm text-muted-foreground">Texture problems in cakes</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
