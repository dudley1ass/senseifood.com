import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCakesAreDense() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cake Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cakes Are Dense
          </h1>
          <p className="text-xl text-muted-foreground">
            The science of cake structure and how to achieve a light, tender crumb every time.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>6 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              A dense cake is heavy, gummy, and nothing like the light, airy crumb you were hoping for. Density in cakes comes from insufficient air incorporation, too much moisture, weak leavening, or overdeveloped gluten. Each cause has a specific fix.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Cake texture is a balance between structure (flour, eggs) and tenderness (fat, sugar). When structure dominates — or when air hasn't been properly incorporated — you get a dense, heavy result.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Insufficient Creaming</h3>
                <p className="text-muted-foreground leading-relaxed">Creaming butter and sugar together incorporates air bubbles that expand in the oven and create lift. Under-creaming (less than 3–5 minutes) means fewer bubbles and a denser crumb.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Too Much Flour</h3>
                <p className="text-muted-foreground leading-relaxed">Over-measuring flour is the most common cause of dense cakes. Too much flour relative to fat and liquid creates a heavy, dry, dense texture. Always spoon and level.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Old or Insufficient Leavening</h3>
                <p className="text-muted-foreground leading-relaxed">Baking powder and baking soda lose potency over time. Weak leavening means less CO2 gas production and less lift. Replace every 6–12 months.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Overmixing After Adding Flour</h3>
                <p className="text-muted-foreground leading-relaxed">Once flour hits wet ingredients, gluten begins developing. Overmixing builds a tough, dense gluten network. Fold flour in gently until just combined.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Cold Ingredients</h3>
                <p className="text-muted-foreground leading-relaxed">Cold butter won't cream properly. Cold eggs can cause the batter to curdle, losing the emulsion that traps air. Always use room temperature ingredients.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Too Much Liquid</h3>
                <p className="text-muted-foreground leading-relaxed">Excess liquid dilutes the structure and creates a gummy, dense texture. The batter can't set properly and collapses as it cools.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Keys to a Light, Airy Cake</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Cream butter and sugar 4–5 minutes until pale and fluffy</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use room temperature butter, eggs, and dairy</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Spoon and level flour — never scoop</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Fold in flour gently — stop when just combined</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Test leavening freshness before each bake</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Cream butter fully</li>
                  <li>• Use room temp ingredients</li>
                  <li>• Sift flour</li>
                  <li>• Fold gently</li>
                  <li>• Use fresh leavening</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Under-cream butter</li>
                  <li>• Use cold eggs</li>
                  <li>• Scoop flour</li>
                  <li>• Overmix after flour</li>
                  <li>• Use expired baking powder</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cake-science/why-cakes-sink" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Sink</h4>
                <p className="text-sm text-muted-foreground">Related structural issues</p>
              </Link>
              <Link to="/cake-science/why-cakes-collapse" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Collapse</h4>
                <p className="text-sm text-muted-foreground">When cakes fall apart</p>
              </Link>
              <Link to="/cake-science/why-cakes-crack-on-top" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Crack on Top</h4>
                <p className="text-sm text-muted-foreground">Surface issues in baking</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
