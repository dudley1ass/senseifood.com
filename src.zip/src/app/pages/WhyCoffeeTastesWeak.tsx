import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCoffeeTastesWeak() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Coffee Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Coffee Tastes Weak
          </h1>
          <p className="text-xl text-muted-foreground">
            The extraction science behind under-strength coffee and how to brew a bolder cup.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Weak coffee is under-extracted or under-dosed — meaning either not enough coffee was used, or not enough compounds were dissolved from the grounds. The result is a thin, watery cup that lacks body, aroma, and flavor.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Coffee strength (total dissolved solids) and extraction (percentage of coffee mass dissolved) are two different variables. You can have high extraction with weak coffee if you used too little coffee to begin with.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Too Little Coffee</h3>
                <p className="text-muted-foreground leading-relaxed">The most direct cause. The Specialty Coffee Association recommends 1:15–1:17 coffee to water ratio by weight. Using less coffee means less material to extract, regardless of technique.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Under-Extraction</h3>
                <p className="text-muted-foreground leading-relaxed">Under-extraction happens when water doesn't dissolve enough from the grounds — usually from water that's too cool, grind too coarse, or brew time too short. Under-extracted coffee tastes sour and thin.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Grind Too Coarse</h3>
                <p className="text-muted-foreground leading-relaxed">Coarser grinds have less surface area, slowing extraction. For a given brew time and temperature, a coarser grind extracts less. Grinding finer increases surface area and extraction.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Water Too Cool</h3>
                <p className="text-muted-foreground leading-relaxed">Water below 90°C (195°F) extracts compounds too slowly. Optimal brewing temp is 90–96°C (195–205°F). Boiling water (100°C) can over-extract, but cool water under-extracts.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Brew Time Too Short</h3>
                <p className="text-muted-foreground leading-relaxed">Insufficient contact time between water and grounds results in low extraction. Each brew method has an optimal time: espresso 25–30 sec, pour over 3–4 min, French press 4 min.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Stale Coffee</h3>
                <p className="text-muted-foreground leading-relaxed">Stale coffee has lost its volatile aromatic compounds through oxidation. Even with perfect technique, stale beans produce a flat, weak-tasting cup. Use freshly roasted beans within 2–4 weeks of roast date.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Brew Stronger Coffee</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use 1g coffee per 15ml water (1:15 ratio) as a starting point</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Grind finer — gradually, one step at a time</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Brew at 93–96°C (200–205°F)</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Extend brew time by 30 seconds</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use freshly roasted beans within 2–4 weeks of roast date</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Weigh your coffee and water</li>
                  <li>• Use fresh beans</li>
                  <li>• Grind just before brewing</li>
                  <li>• Use correct water temp</li>
                  <li>• Adjust one variable at a time</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use pre-ground stale coffee</li>
                  <li>• Use cool water</li>
                  <li>• Rush the brew</li>
                  <li>• Eyeball your dose</li>
                  <li>• Change multiple variables at once</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/coffee-science/coffee-extraction-science" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Coffee Extraction Science</h4>
                <p className="text-sm text-muted-foreground">The full extraction deep dive</p>
              </Link>
              <Link to="/coffee-science/why-coffee-tastes-bitter" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Coffee Tastes Bitter</h4>
                <p className="text-sm text-muted-foreground">Over-extraction problems</p>
              </Link>
              <Link to="/coffee-science/why-coffee-tastes-sour" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Coffee Tastes Sour</h4>
                <p className="text-sm text-muted-foreground">Under-extraction problems</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
