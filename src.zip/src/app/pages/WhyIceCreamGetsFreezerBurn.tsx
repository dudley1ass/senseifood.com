import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyIceCreamGetsFreezerBurn() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Ice Cream Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Ice Cream Gets Freezer Burn
          </h1>
          <p className="text-xl text-muted-foreground">
            The sublimation and recrystallization science behind icy, grainy ice cream — and how to prevent it.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              You open a container of ice cream that's been in the freezer for a few weeks and find a layer of frost on top and a grainy, icy texture beneath. That's freezer burn — and it's caused by moisture migration, not actual burning.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Freezer burn in ice cream is a combination of sublimation (ice crystals converting directly to vapor) and recrystallization (small crystals merging into large, gritty ones). Both processes degrade texture significantly.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Temperature Fluctuations</h3>
                <p className="text-muted-foreground leading-relaxed">Every time the freezer warms slightly (door opening, defrost cycle), some ice crystals melt. When it refreezes, those water molecules recrystallize — but into larger crystals. Repeated cycles = progressively icier texture.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Exposed Surface Area</h3>
                <p className="text-muted-foreground leading-relaxed">Air space above ice cream allows sublimation. Moisture leaves the ice cream surface and deposits as frost on the lid. Press plastic wrap directly onto the surface to eliminate air contact.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Improper Container Seal</h3>
                <p className="text-muted-foreground leading-relaxed">A loose or non-airtight lid allows moisture exchange between the ice cream and freezer air. Use containers with tight-fitting lids, and press a layer of plastic wrap directly onto the surface.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Storing Too Long</h3>
                <p className="text-muted-foreground leading-relaxed">Even in perfect conditions, ice cream degrades over time. Home ice cream without stabilizers is best within 1–2 weeks. Commercial ice cream within 2–3 months of opening.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Low Stabilizer Content</h3>
                <p className="text-muted-foreground leading-relaxed">Stabilizers bind free water and prevent it from migrating. Homemade ice cream without stabilizers is much more vulnerable to freezer burn than commercial versions.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Freezer Too Warm</h3>
                <p className="text-muted-foreground leading-relaxed">Freezers set above 0°F (-18°C) allow too much water to remain unfrozen, accelerating crystal migration and recrystallization. Set freezer to 0°F or below.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Prevent Freezer Burn</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Press plastic wrap directly onto ice cream surface before lidding</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use airtight containers — avoid cardboard tubs for long storage</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Keep freezer at 0°F (-18°C) or below</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Minimize temperature fluctuations — don't leave freezer open</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Add 0.1–0.2% stabilizer blend to homemade recipes</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Press wrap to surface</li>
                  <li>• Use airtight container</li>
                  <li>• Keep freezer cold</li>
                  <li>• Consume within 2 weeks (homemade)</li>
                  <li>• Add stabilizers to homemade</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Leave air above ice cream</li>
                  <li>• Use loose lids</li>
                  <li>• Allow temp fluctuations</li>
                  <li>• Store too long</li>
                  <li>• Set freezer too warm</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/ice-cream-science/why-ice-cream-gets-icy" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Gets Icy</h4>
                <p className="text-sm text-muted-foreground">Crystal formation science</p>
              </Link>
              <Link to="/ice-cream-science/why-ice-cream-is-creamy" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Is Creamy</h4>
                <p className="text-sm text-muted-foreground">Smooth texture science</p>
              </Link>
              <Link to="/ice-cream-science/why-ice-cream-melts-fast" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Melts Fast</h4>
                <p className="text-sm text-muted-foreground">Melt rate and stability</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
