import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyPieCrustShrinks() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Pie Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Pie Crust Shrinks
          </h1>
          <p className="text-xl text-muted-foreground">
            The gluten science behind shrinking pie crust and how to roll, rest, and bake for a perfect fit.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              You carefully drape your pie crust into the pan, crimp the edges, and pop it in the oven — only to find the sides have shrunk down the pan, leaving a shallow shell. Shrinkage is caused by gluten tension in the dough snapping back when heat is applied.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Pie crust shrinks because gluten — the protein network formed when flour and water are mixed — wants to return to its original shape after being stretched. Proper technique eliminates or controls this tension.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Overworked Dough</h3>
                <p className="text-muted-foreground leading-relaxed">The more you handle pie dough, the more gluten develops. More gluten = more tension = more shrinkage. Mix just until the dough comes together and handle as little as possible.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Skipping the Rest</h3>
                <p className="text-muted-foreground leading-relaxed">After mixing, gluten strands are tense and tight. Resting the dough in the fridge for at least 1 hour (ideally overnight) allows gluten to relax. Relaxed gluten shrinks less.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Stretching Into the Pan</h3>
                <p className="text-muted-foreground leading-relaxed">If you stretch the dough to fit the pan rather than letting it fall in naturally, you're pre-loading tension. When that tension releases in the oven — shrinkage. Let the dough drape in under its own weight.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Not Chilling Before Baking</h3>
                <p className="text-muted-foreground leading-relaxed">Chilled fat (butter or lard) holds the dough structure until the oven heat sets it. Room temperature dough goes slack immediately and slides down the pan.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. No Pie Weights for Blind Baking</h3>
                <p className="text-muted-foreground leading-relaxed">Without weights, the sides have nothing to lean against and slide down. Use pie weights, dried beans, or even sugar to fill the shell when blind baking.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Rolling Too Thin</h3>
                <p className="text-muted-foreground leading-relaxed">Very thin crust has less structural integrity and shrinks more dramatically. Roll to an even 1/8 inch thickness — not thinner.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Prevent Crust Shrinkage</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Rest dough at least 1 hour in fridge — overnight is better</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Drape dough into pan — don't stretch it</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Press gently into corners without pulling</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Chill the lined pan 30 min before baking</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Always use pie weights when blind baking</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Rest dough before rolling</li>
                  <li>• Chill before baking</li>
                  <li>• Use pie weights</li>
                  <li>• Let dough drape naturally</li>
                  <li>• Roll to even thickness</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Stretch dough to fit</li>
                  <li>• Skip resting</li>
                  <li>• Blind bake without weights</li>
                  <li>• Overwork the dough</li>
                  <li>• Use warm dough</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/pie-science/why-pie-crust-is-flaky" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Pie Crust Is Flaky</h4>
                <p className="text-sm text-muted-foreground">The science of flaky layers</p>
              </Link>
              <Link to="/cookie-science/why-cookies-dont-spread" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Don't Spread</h4>
                <p className="text-sm text-muted-foreground">Similar gluten science</p>
              </Link>
              <Link to="/bread-science/why-bread-rises" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Bread Rises</h4>
                <p className="text-sm text-muted-foreground">More gluten and structure science</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
