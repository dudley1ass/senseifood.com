import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCoffeeTastesBurnt() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Coffee Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Coffee Tastes Burnt
          </h1>
          <p className="text-xl text-muted-foreground">
            The science of scorched, over-roasted, and over-extracted coffee — and how to fix it.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Burnt coffee can come from over-roasted beans, water that's too hot, keeping coffee on heat after brewing, or over-extraction. The bitter, acrid, ashy quality isn't just unpleasant — it means specific compounds have been degraded or formed through heat damage.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              True 'burnt' flavor comes from carbon compounds formed when organic material is exposed to excessive heat. In coffee, this happens at the roaster, in the brewer, or on the warming plate after brewing.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Dark Over-Roasted Beans</h3>
                <p className="text-muted-foreground leading-relaxed">Dark roasts push beans past the second crack, converting fruity and floral compounds into carbon-based bitter ones. Very dark roasts ('French' or 'Italian') are intentionally carbonized — if you dislike burnt flavor, choose medium roasts.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Water Too Hot</h3>
                <p className="text-muted-foreground leading-relaxed">Water above 96°C (205°F) extracts harsh, bitter compounds too aggressively. At or near boiling (100°C), coffee tastes bitter and burnt. Let boiled water rest 30 seconds before brewing.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Leaving Coffee on a Warming Plate</h3>
                <p className="text-muted-foreground leading-relaxed">Brewed coffee left on a warming plate continues to cook. After 20–30 minutes, the coffee oxidizes and scorches, creating that classic diner burnt coffee taste. Use a thermal carafe instead.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Over-Extraction</h3>
                <p className="text-muted-foreground leading-relaxed">Brewing too long or grinding too fine extracts bitter, high-molecular-weight compounds that should stay in the grounds. These taste harsh, astringent, and burnt even without actual heat damage.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Dirty Equipment</h3>
                <p className="text-muted-foreground leading-relaxed">Coffee oils left in a machine oxidize and turn rancid. These old oils coat new coffee with a harsh, burnt, bitter flavor. Clean equipment weekly with coffee equipment cleaner.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Espresso Channeling</h3>
                <p className="text-muted-foreground leading-relaxed">In espresso, channeling occurs when water finds a path of least resistance through the puck, over-extracting one area while under-extracting others. The over-extracted channels taste burnt and bitter.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Eliminate Burnt Coffee Flavor</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Switch to medium roast beans</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Let boiled water rest 30–45 seconds before pouring</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Transfer brewed coffee to thermal carafe immediately</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Grind slightly coarser to reduce extraction</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Clean machine and grinder weekly</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use medium roast</li>
                  <li>• Control water temp</li>
                  <li>• Use thermal carafe</li>
                  <li>• Clean equipment regularly</li>
                  <li>• Grind consistently</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Leave coffee on warming plate</li>
                  <li>• Use boiling water</li>
                  <li>• Use dark over-roasted beans</li>
                  <li>• Let oils build up in machine</li>
                  <li>• Over-extract espresso</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/coffee-science/why-coffee-tastes-bitter" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Coffee Tastes Bitter</h4>
                <p className="text-sm text-muted-foreground">Bitterness vs burnt flavor</p>
              </Link>
              <Link to="/coffee-science/coffee-extraction-science" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Coffee Extraction Science</h4>
                <p className="text-sm text-muted-foreground">Full extraction science</p>
              </Link>
              <Link to="/coffee-science/why-coffee-tastes-weak" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Coffee Tastes Weak</h4>
                <p className="text-sm text-muted-foreground">Under-extraction problems</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
