import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCookiesGetCrispy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cookie Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cookies Get Crispy
          </h1>
          <p className="text-xl text-muted-foreground">
            The science of low moisture, high sugar, and the Maillard reaction that creates perfectly crisp cookies.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Crispy cookies are the result of low moisture content, high sugar levels, and the right baking temperature. When moisture evaporates during baking, the sugar and starch matrix sets into a rigid, crunchy structure. Understanding this process lets you dial in exactly how crispy you want your cookies.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              The Maillard reaction — the same browning that gives bread its crust and steak its sear — plays a huge role in cookie crispness. Higher temperatures and longer bake times drive more browning and more moisture loss, both of which increase crispness.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Higher White Sugar Ratio</h3>
                <p className="text-muted-foreground leading-relaxed">White sugar spreads more and creates crisper cookies. Unlike brown sugar (which retains moisture via molasses), white sugar produces a drier, more rigid cookie structure as it caramelizes.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. More Butter, Less Egg</h3>
                <p className="text-muted-foreground leading-relaxed">Butter contributes fat that shortens the gluten structure, while reducing eggs means less protein to hold moisture. Less moisture = crisper cookie.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Longer Bake Time at Lower Temp</h3>
                <p className="text-muted-foreground leading-relaxed">Baking at 325°F for longer allows moisture to slowly evaporate without burning. This is the technique behind shortbread — pale on top but fully dry and crisp throughout.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Thinner Dough</h3>
                <p className="text-muted-foreground leading-relaxed">Thinner cookies have less mass to hold moisture. Rolling or pressing dough thinner allows it to fully dry out during baking.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Cooling on a Wire Rack</h3>
                <p className="text-muted-foreground leading-relaxed">Placing hot cookies on a wire rack allows airflow underneath, preventing steam from softening the bottom. Steam trapped under cookies on a solid surface makes them soft.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Low Humidity Storage</h3>
                <p className="text-muted-foreground leading-relaxed">Crispy cookies absorb moisture from the air over time. Store in an airtight container with a silica packet or a sugar cube to absorb ambient moisture.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Ideal Ratios for Crispy Cookies</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>All white sugar or 2:1 white to brown ratio</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Softened (not melted) butter creamed with sugar</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>One egg or egg white only (less yolk = less fat/moisture)</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>All-purpose flour (lower protein than bread flour)</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Bake at 325–350°F until fully golden, not just set</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use all white sugar</li>
                  <li>• Bake fully golden</li>
                  <li>• Cool on wire rack</li>
                  <li>• Store airtight</li>
                  <li>• Roll dough thin</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use melted butter</li>
                  <li>• Underbake</li>
                  <li>• Stack while warm</li>
                  <li>• Store near steam</li>
                  <li>• Use bread flour</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cookie-science/why-cookies-spread" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Spread</h4>
                <p className="text-sm text-muted-foreground">Control cookie spread and shape</p>
              </Link>
              <Link to="/cookie-science/why-cookies-turn-hard" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Turn Hard</h4>
                <p className="text-sm text-muted-foreground">Keep cookies fresh longer</p>
              </Link>
              <Link to="/cookie-science/brown-sugar-vs-white-sugar" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Brown vs White Sugar</h4>
                <p className="text-sm text-muted-foreground">How sugar type changes texture</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
