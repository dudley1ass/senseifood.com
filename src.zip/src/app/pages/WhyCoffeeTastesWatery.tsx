import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCoffeeTastesWatery() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Coffee Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Coffee Tastes Watery
          </h1>
          <p className="text-xl text-muted-foreground">
            The difference between weak and watery coffee — and how to brew with more body and mouthfeel.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Watery coffee is distinct from weak coffee — watery means low body and mouthfeel, while weak means low flavor intensity. You can have watery coffee with decent flavor but no thickness, or weak coffee with some body but little taste. Often both occur together.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Body in coffee comes from dissolved solids, oils, and fine particles suspended in the brew. Brewing method, grind size, filtration, and coffee origin all determine how much body ends up in your cup.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Paper Filter Removing Oils</h3>
                <p className="text-muted-foreground leading-relaxed">Paper filters capture coffee oils (cafestol and kahweol) that contribute significantly to body. French press, Moka pot, and metal filter methods preserve these oils and produce fuller-bodied coffee.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Too Little Coffee</h3>
                <p className="text-muted-foreground leading-relaxed">Low coffee-to-water ratio is the primary cause of both weak and watery coffee. Increasing dose immediately increases both flavor intensity and body.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Grind Too Coarse</h3>
                <p className="text-muted-foreground leading-relaxed">Coarser grinds extract less and leave fewer fine particles in the brew. Finer grinding increases dissolved solids and body. Adjust grind one step finer and taste.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Low-Density Beans</h3>
                <p className="text-muted-foreground leading-relaxed">Specialty high-altitude beans are denser and have more soluble material per gram. Commodity or lower-grown beans often have less material to extract, contributing to thinner body.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Brew Method</h3>
                <p className="text-muted-foreground leading-relaxed">Drip coffee with paper filter consistently produces lighter body than French press or Moka pot. If you want more body without changing recipe, switch methods or use a metal filter.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Water Quality</h3>
                <p className="text-muted-foreground leading-relaxed">Very soft (low mineral) water doesn't carry extracted compounds as effectively as water with moderate mineral content. Ideal brewing water has 75–150 ppm total dissolved solids.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Add Body to Coffee</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Increase coffee dose — try 1:14 or 1:13 ratio</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Switch to metal filter or French press</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Grind one step finer</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use water with moderate mineral content (75–150 ppm TDS)</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Try beans from high-altitude origins (Ethiopia, Colombia, Guatemala)</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use metal filter for more body</li>
                  <li>• Increase coffee dose</li>
                  <li>• Grind finer</li>
                  <li>• Use mineral water</li>
                  <li>• Try French press</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use too much water</li>
                  <li>• Use paper filter if body is priority</li>
                  <li>• Use very soft water</li>
                  <li>• Use light dose</li>
                  <li>• Use low-quality beans</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/coffee-science/why-coffee-tastes-weak" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Coffee Tastes Weak</h4>
                <p className="text-sm text-muted-foreground">Strength vs body</p>
              </Link>
              <Link to="/coffee-science/coffee-extraction-science" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Coffee Extraction Science</h4>
                <p className="text-sm text-muted-foreground">Full extraction science</p>
              </Link>
              <Link to="/coffee-science/why-coffee-tastes-bitter" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Coffee Tastes Bitter</h4>
                <p className="text-sm text-muted-foreground">Over-extraction problems</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
