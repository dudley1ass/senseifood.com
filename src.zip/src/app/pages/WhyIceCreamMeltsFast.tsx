import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyIceCreamMeltsFast() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Ice Cream Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Ice Cream Melts Fast
          </h1>
          <p className="text-xl text-muted-foreground">
            The thermodynamics and formulation science behind melt rate in ice cream.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Some ice creams hold their shape beautifully in a bowl for minutes, while others collapse into puddles almost immediately. Melt rate is determined by fat content, overrun (air), stabilizers, and serving temperature — all of which can be controlled.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Ice cream melts when heat transfers from the environment into the frozen mass, converting ice crystals to liquid water. The rate depends on thermal conductivity, surface area, and how the mixture was formulated.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Low Fat Content</h3>
                <p className="text-muted-foreground leading-relaxed">Fat slows melting by acting as a thermal insulator and by trapping water in emulsified droplets. Low-fat or light ice creams melt faster because there's less fat to slow heat transfer.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. High Overrun (Too Much Air)</h3>
                <p className="text-muted-foreground leading-relaxed">Overrun is the percentage of air whipped into ice cream. High overrun (cheap ice cream) melts faster because air is a poor insulator and the lower density means less frozen mass per scoop.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Lack of Stabilizers</h3>
                <p className="text-muted-foreground leading-relaxed">Stabilizers (guar gum, carrageenan, locust bean gum) bind free water and slow melting. Homemade ice cream without stabilizers melts faster than commercial versions.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Large Ice Crystals</h3>
                <p className="text-muted-foreground leading-relaxed">Large ice crystals (from slow freezing or temperature fluctuations) melt faster than small crystals. Small crystals formed by rapid freezing have more surface area but melt more slowly as a mass.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Warm Serving Temperature</h3>
                <p className="text-muted-foreground leading-relaxed">Ice cream served at -5°C melts slower than ice cream served at -2°C. Temper briefly before serving but don't let it warm too much before scooping.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. High Sugar Content</h3>
                <p className="text-muted-foreground leading-relaxed">Sugar lowers the freezing point of water (freezing point depression). Very high sugar formulas stay softer and melt faster because more water remains unfrozen even at freezer temperatures.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Slow Ice Cream Melt Rate</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use full-fat dairy — minimum 10% milkfat</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Add egg yolks (custard base) for richness and emulsification</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use a small amount of stabilizer (0.1–0.3% by weight)</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Freeze rapidly — use a pre-chilled bowl and cold base</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Serve at -5°C to -8°C for best texture and slower melt</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use full-fat dairy</li>
                  <li>• Add egg yolks</li>
                  <li>• Freeze rapidly</li>
                  <li>• Use stabilizers</li>
                  <li>• Serve at proper temp</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use skim milk</li>
                  <li>• Allow temperature fluctuations</li>
                  <li>• Over-churn</li>
                  <li>• Serve too warm</li>
                  <li>• Skip the custard base</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/ice-cream-science/why-ice-cream-gets-icy" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Gets Icy</h4>
                <p className="text-sm text-muted-foreground">Crystal formation science</p>
              </Link>
              <Link to="/ice-cream-science/why-ice-cream-is-creamy" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Is Creamy</h4>
                <p className="text-sm text-muted-foreground">The science of smooth texture</p>
              </Link>
              <Link to="/ice-cream-science/why-ice-cream-gets-freezer-burn" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Gets Freezer Burn</h4>
                <p className="text-sm text-muted-foreground">Storage and protection</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
