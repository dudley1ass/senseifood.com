import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCookiesDontSpread() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cookie Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cookies Don't Spread
          </h1>
          <p className="text-xl text-muted-foreground">
            When cookies stay puffy and tall instead of spreading — causes and fixes.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              You expect flat, chewy cookies and instead get thick, puffy domes that barely spread at all. Under-spreading is just as frustrating as over-spreading, and it's caused by the opposite set of conditions — too much structure, too little fat, or dough that's too cold.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Some cookies are designed not to spread (shortbread, pressed cookies, molded cookies). But if your drop cookies aren't spreading when they should, one of these factors is likely the cause.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Dough Too Cold</h3>
                <p className="text-muted-foreground leading-relaxed">Very cold dough takes longer to warm up in the oven, and by the time the fat melts the exterior has already set. Let chilled dough sit at room temp for 10–15 minutes before baking.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Too Much Flour</h3>
                <p className="text-muted-foreground leading-relaxed">Over-measuring flour is the most common cause. Scooping directly with the measuring cup packs in 20–30% more flour than the recipe intends. Always spoon flour into the cup and level off.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Too Much Leavening</h3>
                <p className="text-muted-foreground leading-relaxed">Too much baking powder or baking soda causes cookies to puff up rapidly and set before they have time to spread. The rise happens faster than the spread.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Not Enough Fat</h3>
                <p className="text-muted-foreground leading-relaxed">Fat is what drives spreading. Low butter recipes, or accidentally using less butter than called for, produces cookies that stay thick and cakey.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Cold Baking Sheet</h3>
                <p className="text-muted-foreground leading-relaxed">A cold baking sheet means the bottom of the cookie heats slowly, delaying the fat melt that drives spreading. Always bake on room temperature pans.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Too Much Brown Sugar</h3>
                <p className="text-muted-foreground leading-relaxed">Brown sugar retains moisture and resists spreading compared to white sugar. Very high brown sugar ratios (or all brown sugar) can produce thicker, puffier cookies.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Encourage More Spread</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Let cold dough temper at room temp 10–15 min before baking</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Spoon and level flour — never scoop directly</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Reduce baking powder/soda by 25% if cookies are too puffy</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Swap some brown sugar for white to encourage spread</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Flatten dough balls slightly with your palm before baking</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Temper cold dough</li>
                  <li>• Spoon and level flour</li>
                  <li>• Use room temp baking sheet</li>
                  <li>• Flatten dough slightly</li>
                  <li>• Use some white sugar</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Bake frozen dough</li>
                  <li>• Scoop flour directly</li>
                  <li>• Use excess leavening</li>
                  <li>• Use all brown sugar</li>
                  <li>• Stack pans</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cookie-science/why-cookies-spread-too-much" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Spread Too Much</h4>
                <p className="text-sm text-muted-foreground">Fix overly flat cookies</p>
              </Link>
              <Link to="/cookie-science/why-cookies-flatten" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Flatten</h4>
                <p className="text-sm text-muted-foreground">The science of flat cookies</p>
              </Link>
              <Link to="/cookie-science/why-cookies-are-chewy" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Are Chewy</h4>
                <p className="text-sm text-muted-foreground">Moisture and texture science</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
