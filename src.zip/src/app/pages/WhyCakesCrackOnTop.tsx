import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCakesCrackOnTop() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cake Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cakes Crack on Top
          </h1>
          <p className="text-xl text-muted-foreground">
            Understanding the science behind cracked cake tops and when it's a problem — or a feature.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              A crack down the center of a loaf cake or bundt is often intentional and beautiful. But jagged, uneven cracks on a layer cake or a split top on a cheesecake can ruin your presentation. Understanding why cracks form helps you control them.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Cracks form when the outer crust sets faster than the interior expands. As the batter continues to rise from leavening and steam, it pushes through the already-set crust — creating a crack.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Oven Too Hot</h3>
                <p className="text-muted-foreground leading-relaxed">High heat sets the outer crust before the interior has finished rising. The still-expanding center pushes through the set surface. Lowering oven temp by 25°F allows more even setting.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Too Much Leavening</h3>
                <p className="text-muted-foreground leading-relaxed">Excess baking powder or soda causes rapid, aggressive rise. The batter expands faster than the crust can accommodate, forcing a crack. Measure leavening precisely.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Overmixing the Batter</h3>
                <p className="text-muted-foreground leading-relaxed">Overmixing develops gluten and incorporates excess air. Too much air expansion in the oven creates pressure that cracks the surface.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Pan Too Small</h3>
                <p className="text-muted-foreground leading-relaxed">When batter overfills the pan, it has nowhere to rise but up and out. The constrained rise cracks the top. Fill pans no more than 2/3 full.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Opening the Oven Too Early</h3>
                <p className="text-muted-foreground leading-relaxed">A sudden drop in temperature causes uneven setting — the partially set crust cracks as the interior collapses and then re-expands.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Dry Batter</h3>
                <p className="text-muted-foreground leading-relaxed">Low moisture batter sets a rigid crust quickly. As the interior expands, the rigid surface cracks instead of stretching. Adding a touch more liquid or fat can help.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Prevent Unwanted Cracks</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Reduce oven temp by 25°F and bake slightly longer</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Fill pans no more than 2/3 full</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Measure leavening precisely with a kitchen scale</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Mix batter only until just combined — stop when streaks disappear</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Don't open the oven in the first 2/3 of bake time</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use correct pan size</li>
                  <li>• Mix until just combined</li>
                  <li>• Bake at proper temp</li>
                  <li>• Use oven thermometer</li>
                  <li>• Let batter rest 5 min before baking</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Overfill the pan</li>
                  <li>• Overmix batter</li>
                  <li>• Open oven early</li>
                  <li>• Use excess leavening</li>
                  <li>• Use too-small pan</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cake-science/why-cakes-dome" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Dome</h4>
                <p className="text-sm text-muted-foreground">Related to cracking — center rise</p>
              </Link>
              <Link to="/cake-science/why-cakes-sink" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Sink</h4>
                <p className="text-sm text-muted-foreground">The opposite problem</p>
              </Link>
              <Link to="/cake-science/why-cakes-collapse" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Collapse</h4>
                <p className="text-sm text-muted-foreground">Structural failure in cakes</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
