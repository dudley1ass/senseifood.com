import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyIceCreamIsCreamy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Ice Cream Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Ice Cream Is Creamy
          </h1>
          <p className="text-xl text-muted-foreground">
            The fat, emulsification, and crystal science that creates smooth, luxurious ice cream texture.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>6 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Creaminess in ice cream comes down to three things: fat content, crystal size, and air incorporation. Premium ice cream has high fat, tiny ice crystals, and moderate air — the combination creates that smooth, rich mouthfeel that melts perfectly on the tongue.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              When you eat ice cream, you're experiencing thousands of tiny ice crystals, fat droplets, and air bubbles held in a frozen matrix. The smaller the crystals and the higher the fat, the creamier the perception.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Fat Content</h3>
                <p className="text-muted-foreground leading-relaxed">Milkfat is the primary driver of creaminess. It coats the tongue, carries flavor, and slows the sensation of cold. Premium ice cream uses 14–18% milkfat vs 10% in economy versions. More fat = more creamy.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Small Ice Crystal Size</h3>
                <p className="text-muted-foreground leading-relaxed">Crystal size is the most critical factor in perceived smoothness. Crystals below 50 microns are imperceptible to the tongue. Rapid freezing, constant churning, and stabilizers all keep crystals small.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Egg Yolk Emulsification</h3>
                <p className="text-muted-foreground leading-relaxed">Egg yolks contain lecithin, a natural emulsifier that keeps fat droplets evenly dispersed. This creates a smoother, more homogeneous texture and slows crystal growth.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Churning Speed and Time</h3>
                <p className="text-muted-foreground leading-relaxed">Churning simultaneously freezes the base and whips in air. Proper churning breaks up ice crystals as they form, keeping them small. Under-churning produces icy, coarse texture.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Sugar Type and Concentration</h3>
                <p className="text-muted-foreground leading-relaxed">Sugar lowers the freezing point and keeps some water unfrozen, contributing to softness. Invert sugar and trehalose are used in premium formulations for their superior anti-crystallization properties.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Homogenization</h3>
                <p className="text-muted-foreground leading-relaxed">Homogenizing the base breaks fat globules into uniform tiny droplets that remain evenly dispersed. This prevents fat separation and contributes to smooth, uniform texture.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Formula for Creamy Ice Cream</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use heavy cream + whole milk for 14–16% total fat</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Make a cooked custard base with egg yolks (4–6 per quart)</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Age the base in fridge 4–24 hours before churning</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Churn in pre-frozen bowl for maximum crystallization speed</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Harden in freezer at least 4 hours after churning</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use heavy cream</li>
                  <li>• Cook a custard base</li>
                  <li>• Age base before churning</li>
                  <li>• Churn in frozen bowl</li>
                  <li>• Harden fully before serving</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use low-fat dairy</li>
                  <li>• Skip aging the base</li>
                  <li>• Churn warm base</li>
                  <li>• Use only white sugar</li>
                  <li>• Serve immediately after churning</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/ice-cream-science/why-ice-cream-gets-icy" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Gets Icy</h4>
                <p className="text-sm text-muted-foreground">Crystal formation and control</p>
              </Link>
              <Link to="/ice-cream-science/why-ice-cream-melts-fast" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Melts Fast</h4>
                <p className="text-sm text-muted-foreground">Melt rate science</p>
              </Link>
              <Link to="/ice-cream-science/why-ice-cream-gets-freezer-burn" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Ice Cream Gets Freezer Burn</h4>
                <p className="text-sm text-muted-foreground">Storage problems</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
