import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCakesDryOut() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cake Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cakes Dry Out
          </h1>
          <p className="text-xl text-muted-foreground">
            The science of moisture retention in cakes and how to keep them fresh for days.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              A cake that was moist on day one but dry by day two is one of the most common baking disappointments. Drying out happens through moisture evaporation, starch retrogradation, and improper storage. Understanding these mechanisms lets you bake cakes that stay moist longer.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Moisture in cake comes from eggs, fat, and liquid. Fat coats the starch granules and slows moisture loss. Sugar is hygroscopic and holds moisture. When these are in balance, a cake stays moist for days.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Overbaking</h3>
                <p className="text-muted-foreground leading-relaxed">The #1 cause of dry cake. Every extra minute in the oven drives out more moisture. Pull the cake when a toothpick comes out with a few moist crumbs — not completely clean.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Too Much Flour</h3>
                <p className="text-muted-foreground leading-relaxed">Excess flour absorbs moisture from the batter and from the finished cake over time. Over-measured flour is the most common structural cause of dry texture.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Not Enough Fat</h3>
                <p className="text-muted-foreground leading-relaxed">Fat slows moisture evaporation and lubricates the crumb. Low-fat recipes dry out faster. Adding an extra tablespoon of oil to butter-based cakes dramatically improves moisture retention.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Improper Storage</h3>
                <p className="text-muted-foreground leading-relaxed">Exposed cake stales rapidly. Unfrosted cakes should be wrapped tightly in plastic wrap while still slightly warm (traps steam). Frosted cakes should be stored in a cake dome or airtight container.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. Refrigerating Unfrosted Cake</h3>
                <p className="text-muted-foreground leading-relaxed">The refrigerator is a dry environment that rapidly stales cake via starch retrogradation. Only refrigerate frosted cakes or cakes with perishable fillings — and only when necessary.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Starch Retrogradation</h3>
                <p className="text-muted-foreground leading-relaxed">Over time, the starch structure in cake realigns and expels water (syneresis). This is the scientific reason all baked goods stale. It happens faster at fridge temperatures, slower at room temp, and is paused when frozen.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Keep Cakes Moist</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Pull cake when toothpick has moist crumbs — not clean</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Add 1–2 tbsp vegetable oil alongside butter for moisture</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Brush warm cake layers with simple syrup to add moisture</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Wrap unfrosted cake layers tightly in plastic while warm</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Freeze layers if not using within 2 days — thaw wrapped</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use simple syrup soak</li>
                  <li>• Wrap while warm</li>
                  <li>• Add oil to recipe</li>
                  <li>• Freeze for longer storage</li>
                  <li>• Underbake slightly</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Overbake</li>
                  <li>• Refrigerate unfrosted cake</li>
                  <li>• Leave cake uncovered</li>
                  <li>• Over-measure flour</li>
                  <li>• Store in warm place</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cake-science/why-cakes-are-dense" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Are Dense</h4>
                <p className="text-sm text-muted-foreground">Related texture problems</p>
              </Link>
              <Link to="/cake-science/why-cakes-sink" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Sink</h4>
                <p className="text-sm text-muted-foreground">Structural issues in baking</p>
              </Link>
              <Link to="/cake-science/why-cakes-stick-to-pan" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cakes Stick to Pan</h4>
                <p className="text-sm text-muted-foreground">Pan release science</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
