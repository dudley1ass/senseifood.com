import { ArrowLeft, Clock, User } from 'lucide-react';
import { Link } from 'react-router';
import { Navigation } from '../components/Navigation';
import { Footer } from '../components/Footer';

export default function WhyCookiesFlatten() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50">
      <Navigation />
      
      <article className="max-w-4xl mx-auto px-6 py-16">
        <Link 
          to="/articles" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Articles
        </Link>

        <header className="mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-full text-sm mb-6">
            Cookie Science
          </div>
          <h1 className="text-5xl md:text-6xl mb-6 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
            Why Cookies Flatten
          </h1>
          <p className="text-xl text-muted-foreground">
            Understanding the causes of flat cookies and how to get the height and shape you want.
          </p>
          <div className="flex items-center gap-4 mt-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>5 min read</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4" />
              <span>SenseiFood Team</span>
            </div>
          </div>
        </header>

        <div className="prose prose-lg max-w-none">
          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">The Science</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Flat cookies happen when the dough spreads too fast before the structure can set in the oven. The main culprits are butter temperature, too much sugar, too little flour, and oven temperature. Once you understand what drives spreading, you can control it precisely.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Flattening is different from intentional spreading — a flat cookie has spread so much it has almost no height, while a properly spread cookie still has some thickness and a chewy center.
            </p>
          </section>

          <section className="mb-12 bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">Key Factors</h2>
            <div className="space-y-6">
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">1. Butter Too Warm or Melted</h3>
                <p className="text-muted-foreground leading-relaxed">Warm or melted butter spreads immediately when it hits the oven, before the structure has time to set. Cold or softened (not melted) butter holds its shape longer, giving the cookie time to set before spreading.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">2. Too Much Sugar</h3>
                <p className="text-muted-foreground leading-relaxed">Sugar liquefies as it heats, causing spread. High sugar ratios — especially white sugar — create more liquid during baking and result in flatter cookies.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">3. Too Little Flour</h3>
                <p className="text-muted-foreground leading-relaxed">Flour provides structure. Too little means there's not enough starch and protein matrix to hold the cookie's shape as the fats and sugars melt.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">4. Oven Too Hot</h3>
                <p className="text-muted-foreground leading-relaxed">A very hot oven melts the butter instantly before the egg proteins and starch have a chance to set. Lower oven temps allow structure to form before full spread occurs.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">5. No Chilling</h3>
                <p className="text-muted-foreground leading-relaxed">Chilling dough solidifies the fat, so it takes longer to melt in the oven — giving the structure more time to set before spreading. Even 30 minutes in the fridge makes a visible difference.</p>
              </div>
              <div className="bg-white rounded-xl p-6 shadow-md">
                <h3 className="text-2xl mb-3 text-foreground">6. Over-greased Pan</h3>
                <p className="text-muted-foreground leading-relaxed">Too much butter or non-stick spray on the pan lets the dough slide and spread easily. Parchment paper provides just enough grip to slow spreading.</p>
              </div>
            </div>
          </section>

          <section className="mb-12 bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-3xl mb-6 bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">How to Prevent Flat Cookies</h2>
            <div className="bg-gradient-to-br from-amber-100 to-orange-100 rounded-xl p-6 mb-6">
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Use softened butter (65°F) — not melted</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Chill dough at least 30 minutes before baking</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Measure flour correctly — spoon into cup, don't scoop</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Bake on parchment paper, not greased pan</span></li>
                <li className="flex items-start gap-2"><span className="text-amber-600 text-lg">•</span><span>Start oven at correct temp — use an oven thermometer</span></li>
              </ul>
            </div>
          </section>

          <section className="mb-12 bg-gradient-to-br from-orange-50 to-amber-50 rounded-2xl p-8">
            <h2 className="text-3xl mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">Quick Tips</h2>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✓ Do:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Chill the dough</li>
                  <li>• Use softened butter</li>
                  <li>• Measure flour properly</li>
                  <li>• Use parchment paper</li>
                  <li>• Check oven temp</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-6">
                <p className="text-foreground mb-2"><strong>✗ Don't:</strong></p>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>• Use melted butter</li>
                  <li>• Skip chilling</li>
                  <li>• Over-grease the pan</li>
                  <li>• Pack flour when measuring</li>
                  <li>• Open oven early</li>
                </ul>
              </div>
            </div>
          </section>

          <div className="bg-gradient-to-br from-amber-600 to-orange-600 rounded-3xl p-10 text-white my-16 shadow-2xl">
            <h3 className="text-3xl mb-4">Apply This Science to Your Recipes</h3>
            <p className="text-white/90 mb-6 text-lg">
              Use CookieSensei to experiment with ingredient ratios and see exactly how changes affect texture, spread, and structure.
            </p>
            <a 
              href="https://cookiesensei.senseifood.com" 
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-white text-amber-600 px-8 py-4 rounded-xl font-bold hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              Try CookieSensei →
            </a>
          </div>

          <section className="mt-16">
            <h3 className="text-2xl mb-6 text-foreground">Related Articles</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <Link to="/cookie-science/why-cookies-spread" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Spread</h4>
                <p className="text-sm text-muted-foreground">The full science of cookie spread</p>
              </Link>
              <Link to="/cookie-science/why-cookies-spread-too-much" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Spread Too Much</h4>
                <p className="text-sm text-muted-foreground">Diagnose and fix flat cookies</p>
              </Link>
              <Link to="/cookie-science/why-cookies-dont-spread" className="bg-white rounded-xl p-6 hover:shadow-lg transition-shadow">
                <h4 className="text-lg mb-2 bg-gradient-to-r from-amber-500 to-orange-600 bg-clip-text text-transparent">Why Cookies Don't Spread</h4>
                <p className="text-sm text-muted-foreground">When cookies stay too puffy</p>
              </Link>
            </div>
          </section>
        </div>
      </article>

      <Footer />
    </div>
  );
}
